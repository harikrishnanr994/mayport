<?php

$my_email = 'phacsindevs@gmail.com';

$SMTP = array(
    'enabled' => true,
    'host' => 'mail.mayport-heritreat.com',
    'username' => 'admin@mayport-heritreat.com',
    'password' => 'admin@mayport',
    'port' => 587,

);
